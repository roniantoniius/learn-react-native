/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            backgroundColor: '#f5f6f8',
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            borderBottomRightRadius: 35,
            borderBottomLeftRadius: 35,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <ImageBackground
            style={{
              width: 421,
              height: 30,
              position: 'relative',
              zIndex: 57,
              marginTop: 7,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 6,
            }}
            source={require('./assets/images/a973a5ce-7a52-497d-a5aa-d673aaaac1ad.png')}
            resizeMode='cover'
          />
          <Text
            style={{
              height: 35,
              fontFamily: 'Poppins',
              fontSize: 26,
              fontWeight: '600',
              lineHeight: 35,
              color: '#052844',
              position: 'relative',
              textAlign: 'left',
              zIndex: 5,
              marginTop: 6,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 143,
            }}
            numberOfLines={1}
          >
            Jejak Laut
          </Text>
          <View
            style={{
              width: 361,
              height: 212,
              fontSize: 0,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              zIndex: 31,
              marginTop: 38,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <Text
              style={{
                height: 19,
                fontFamily: 'Poppins',
                fontSize: 13,
                fontWeight: '600',
                lineHeight: 19,
                color: '#052844',
                position: 'relative',
                textAlign: 'left',
                zIndex: 33,
                marginTop: 8,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 15,
              }}
              numberOfLines={1}
            >
              Informasi Kamu !
            </Text>
            <View
              style={{
                height: 24,
                position: 'absolute',
                top: 35,
                left: 15,
                right: 163,
                zIndex: 48,
              }}
            >
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 36,
                }}
              />
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 158,
                  zIndex: 48,
                }}
              />
              <Text
                style={{
                  display: 'flex',
                  height: 11,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 8,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#052844',
                  position: 'absolute',
                  top: 6,
                  left: '50%',
                  textAlign: 'left',
                  zIndex: 41,
                  transform: [{ translateX: -56.5 }],
                }}
                numberOfLines={1}
              >
                3 Perangkap
              </Text>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 11,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 9,
                fontWeight: '600',
                lineHeight: 11,
                color: '#052844',
                position: 'absolute',
                top: 40,
                textAlign: 'left',
                zIndex: 52,
              }}
              numberOfLines={1}
            >
              9 Pancing
            </Text>
            <View
              style={{
                height: 24,
                position: 'absolute',
                top: 70,
                left: 15,
                right: 163,
                zIndex: 49,
              }}
            >
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 37,
                }}
              />
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 158,
                  zIndex: 49,
                }}
              />
              <Text
                style={{
                  display: 'flex',
                  height: 11,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 8,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#052844',
                  position: 'absolute',
                  top: 6,
                  left: '50%',
                  textAlign: 'left',
                  zIndex: 42,
                  transform: [{ translateX: -56.5 }],
                }}
                numberOfLines={1}
              >
                36 Jaring
              </Text>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 11,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 9,
                fontWeight: '600',
                lineHeight: 11,
                color: '#052844',
                position: 'absolute',
                top: 75,
                textAlign: 'left',
                zIndex: 53,
              }}
              numberOfLines={1}
            >
              5 Trawl
            </Text>
            <View
              style={{
                display: 'flex',
                height: 24,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                position: 'absolute',
                top: 105,
                left: 15,
                right: 231,
                zIndex: 43,
              }}
            >
              <View
                style={{
                  width: 25,
                  height: 24,
                  flexShrink: 0,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'relative',
                  zIndex: 38,
                }}
              />
              <Text
                style={{
                  height: 11,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 8,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#052844',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 43,
                }}
                numberOfLines={1}
              >
                8 Longline
              </Text>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 11,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 9,
                fontWeight: '600',
                lineHeight: 11,
                color: '#052844',
                position: 'absolute',
                top: 113,
                left: '50%',
                textAlign: 'left',
                zIndex: 54,
                transform: [{ translateX: -7.5 }],
              }}
              numberOfLines={1}
            >
              Kapal
            </Text>
            <View
              style={{
                height: 24,
                position: 'absolute',
                top: 140,
                left: 15,
                right: 163,
                zIndex: 50,
              }}
            >
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 39,
                }}
              />
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 158,
                  zIndex: 50,
                }}
              />
              <Text
                style={{
                  display: 'flex',
                  height: 11,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 8,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#052844',
                  position: 'absolute',
                  top: 6,
                  left: '50%',
                  textAlign: 'left',
                  zIndex: 44,
                  transform: [{ translateX: -56.5 }],
                }}
                numberOfLines={1}
              >
                11 Rumpon
              </Text>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 11,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 9,
                fontWeight: '600',
                lineHeight: 11,
                color: '#052844',
                position: 'absolute',
                top: 145,
                textAlign: 'left',
                zIndex: 55,
              }}
              numberOfLines={1}
            >
              Purse Seiner
            </Text>
            <View
              style={{
                height: 24,
                position: 'absolute',
                top: 175,
                left: 15,
                right: 34,
                zIndex: 56,
              }}
            >
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 40,
                }}
              />
              <View
                style={{
                  width: 25,
                  height: 24,
                  backgroundColor: '#ffffff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 158,
                  zIndex: 51,
                }}
              />
              <Text
                style={{
                  display: 'flex',
                  height: 11,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 9,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#052844',
                  position: 'absolute',
                  top: 5,
                  textAlign: 'left',
                  zIndex: 56,
                }}
                numberOfLines={1}
              >
                Cummins QSM11 - 305 HP
              </Text>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 11,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 8,
                fontWeight: '600',
                lineHeight: 11,
                color: '#052844',
                position: 'absolute',
                top: 181,
                left: '50%',
                textAlign: 'left',
                zIndex: 45,
                transform: [{ translateX: -130.5 }],
              }}
              numberOfLines={1}
            >
              29 Jebakan
            </Text>
          </View>
          <View
            style={{
              width: 361,
              height: 473,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              marginTop: 22,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <ImageBackground
              style={{
                width: 361,
                height: 1,
                position: 'relative',
                zIndex: 60,
                marginTop: 39,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/7694cb61-edd1-4e7b-b667-3849340f6a26.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 332,
                height: 151,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                borderBottomRightRadius: 5,
                borderBottomLeftRadius: 5,
                position: 'relative',
                zIndex: 1,
                marginTop: 13,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 15,
              }}
            >
              <View
                style={{
                  width: 315,
                  height: 31,
                  position: 'relative',
                  zIndex: 13,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 8,
                }}
              >
                <View
                  style={{
                    width: 34,
                    height: 31,
                    backgroundColor: '#e8e8e8',
                    borderTopLeftRadius: 5,
                    borderTopRightRadius: 5,
                    borderBottomRightRadius: 5,
                    borderBottomLeftRadius: 5,
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 3,
                  }}
                />
                <Text
                  style={{
                    display: 'flex',
                    height: 18,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 12,
                    fontWeight: '600',
                    lineHeight: 18,
                    color: '#052844',
                    position: 'absolute',
                    top: 6,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 7,
                    transform: [{ translateX: -112.5 }],
                  }}
                  numberOfLines={1}
                >
                  Jaring
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 18,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 10,
                    fontWeight: '600',
                    lineHeight: 15,
                    color: '#525252',
                    position: 'absolute',
                    top: 8,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 8,
                    transform: [{ translateX: -67.5 }],
                  }}
                  numberOfLines={1}
                >
                  | Ikan Tuna
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 11,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 8,
                    fontWeight: '600',
                    lineHeight: 11,
                    color: '#525151',
                    position: 'absolute',
                    top: 8,
                    textAlign: 'left',
                    zIndex: 13,
                  }}
                  numberOfLines={1}
                >
                  Setiap 7 Hari
                </Text>
              </View>
              <ImageBackground
                style={{
                  width: 332,
                  height: 1,
                  position: 'relative',
                  zIndex: 61,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0,
                }}
                source={require('./assets/images/a0e5ac98-13ab-4336-b2b8-392acb646d8d.png')}
                resizeMode='cover'
              />
              <View
                style={{
                  width: 311,
                  height: 22,
                  position: 'relative',
                  zIndex: 22,
                  marginTop: 10,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 9,
                }}
              >
                <Text
                  style={{
                    display: 'flex',
                    width: 212,
                    height: 22,
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '400',
                    lineHeight: 10.5,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    left: '50%',
                    zIndex: 22,
                    transform: [{ translateX: -155.5 }],
                  }}
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    textAlign: 'left',
                    zIndex: 15,
                  }}
                  numberOfLines={1}
                >
                  3 Jam 16 menit 20 detik
                </Text>
              </View>
              <View
                style={{
                  width: 223,
                  height: 10,
                  position: 'relative',
                  zIndex: 21,
                  marginTop: 21,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 9,
                }}
              >
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 17,
                    transform: [{ translateX: -111.5 }],
                  }}
                  numberOfLines={1}
                >
                  19310 meter
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 19,
                    transform: [{ translateX: -53.5 }],
                  }}
                  numberOfLines={1}
                >
                  1.4 Liter / Jam
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    textAlign: 'left',
                    zIndex: 20,
                  }}
                  numberOfLines={1}
                >
                  1.93 Jam
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    textAlign: 'left',
                    zIndex: 21,
                  }}
                  numberOfLines={1}
                >
                  Rp 32.400
                </Text>
              </View>
              <View
                style={{
                  display: 'flex',
                  width: 166,
                  height: 23,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  position: 'relative',
                  zIndex: 25,
                  marginTop: 7,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 162,
                }}
              >
                <Text
                  style={{
                    height: 12,
                    flexShrink: 0,
                    fontFamily: 'Poppins',
                    fontSize: 8,
                    fontWeight: '600',
                    lineHeight: 12,
                    color: '#525151',
                    position: 'relative',
                    textAlign: 'left',
                    zIndex: 11,
                  }}
                  numberOfLines={1}
                >
                  -6.081, 106.895
                </Text>
                <View
                  style={{
                    width: 65,
                    height: 23,
                    flexShrink: 0,
                    backgroundColor: '#b5e4ff',
                    borderTopLeftRadius: 5,
                    borderTopRightRadius: 5,
                    borderBottomRightRadius: 5,
                    borderBottomLeftRadius: 5,
                    position: 'relative',
                    zIndex: 25,
                  }}
                >
                  <Text
                    style={{
                      display: 'flex',
                      height: 11,
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      fontFamily: 'Poppins',
                      fontSize: 10,
                      fontWeight: '600',
                      lineHeight: 11,
                      color: '#000000',
                      position: 'absolute',
                      top: 4,
                      left: '50%',
                      textAlign: 'left',
                      zIndex: 26,
                      transform: [{ translateX: -15.5 }],
                    }}
                    numberOfLines={1}
                  >
                    Lokasi
                  </Text>
                </View>
              </View>
            </View>
            <ImageBackground
              style={{
                width: 361,
                height: 1,
                position: 'relative',
                zIndex: 58,
                marginTop: 17,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/4acfe3d5-5482-4cf3-95f6-c832b0725b2e.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 332,
                height: 151,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                borderBottomRightRadius: 5,
                borderBottomLeftRadius: 5,
                position: 'relative',
                zIndex: 2,
                marginTop: 10,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 15,
              }}
            >
              <View
                style={{
                  width: 315,
                  height: 31,
                  position: 'relative',
                  zIndex: 14,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 8,
                }}
              >
                <View
                  style={{
                    display: 'flex',
                    height: 31,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 197,
                    zIndex: 10,
                  }}
                >
                  <View
                    style={{
                      width: 34,
                      height: 31,
                      flexShrink: 0,
                      backgroundColor: '#e8e8e8',
                      borderTopLeftRadius: 5,
                      borderTopRightRadius: 5,
                      borderBottomRightRadius: 5,
                      borderBottomLeftRadius: 5,
                      position: 'relative',
                      zIndex: 4,
                    }}
                  />
                  <Text
                    style={{
                      height: 18,
                      flexShrink: 0,
                      fontFamily: 'Poppins',
                      fontSize: 12,
                      fontWeight: '600',
                      lineHeight: 18,
                      color: '#052844',
                      position: 'relative',
                      textAlign: 'left',
                      zIndex: 10,
                    }}
                    numberOfLines={1}
                  >
                    Perangkap
                  </Text>
                </View>
                <Text
                  style={{
                    display: 'flex',
                    height: 18,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 10,
                    fontWeight: '600',
                    lineHeight: 15,
                    color: '#525252',
                    position: 'absolute',
                    top: 8,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 9,
                    transform: [{ translateX: -41.5 }],
                  }}
                  numberOfLines={1}
                >
                  | Lobster
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 11,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 8,
                    fontWeight: '600',
                    lineHeight: 11,
                    color: '#525151',
                    position: 'absolute',
                    top: 8,
                    textAlign: 'left',
                    zIndex: 14,
                  }}
                  numberOfLines={1}
                >
                  Setiap 1 Hari
                </Text>
              </View>
              <ImageBackground
                style={{
                  width: 332,
                  height: 1,
                  position: 'relative',
                  zIndex: 62,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0,
                }}
                source={require('./assets/images/7d2d1b8b-961e-4c0a-a5d4-21d0da704eaa.png')}
                resizeMode='cover'
              />
              <View
                style={{
                  width: 311,
                  height: 22,
                  position: 'relative',
                  zIndex: 23,
                  marginTop: 10,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 9,
                }}
              >
                <Text
                  style={{
                    display: 'flex',
                    width: 212,
                    height: 22,
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '400',
                    lineHeight: 10.5,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    left: '50%',
                    zIndex: 23,
                    transform: [{ translateX: -155.5 }],
                  }}
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </Text>
                <Text
                  style={{
                    display: 'flex',
                    height: 10,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 7,
                    fontWeight: '600',
                    lineHeight: 10,
                    color: '#525151',
                    position: 'absolute',
                    top: 0,
                    textAlign: 'left',
                    zIndex: 16,
                  }}
                  numberOfLines={1}
                >
                  24 Jam 01 menit 02 detik
                </Text>
              </View>
              <Text
                style={{
                  height: 10,
                  fontFamily: 'Poppins',
                  fontSize: 7,
                  fontWeight: '600',
                  lineHeight: 10,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 18,
                  marginTop: 21,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 9,
                }}
                numberOfLines={1}
              >
                19310 meter
              </Text>
              <View
                style={{
                  display: 'flex',
                  width: 166,
                  height: 23,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  position: 'relative',
                  zIndex: 28,
                  marginTop: 7,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 162,
                }}
              >
                <Text
                  style={{
                    height: 12,
                    flexShrink: 0,
                    fontFamily: 'Poppins',
                    fontSize: 8,
                    fontWeight: '600',
                    lineHeight: 12,
                    color: '#525151',
                    position: 'relative',
                    textAlign: 'left',
                    zIndex: 12,
                  }}
                  numberOfLines={1}
                >
                  -6.081, 106.895
                </Text>
                <View
                  style={{
                    width: 65,
                    height: 23,
                    flexShrink: 0,
                    backgroundColor: '#b5e4ff',
                    borderTopLeftRadius: 5,
                    borderTopRightRadius: 5,
                    borderBottomRightRadius: 5,
                    borderBottomLeftRadius: 5,
                    position: 'relative',
                    zIndex: 28,
                  }}
                >
                  <Text
                    style={{
                      display: 'flex',
                      height: 11,
                      justifyContent: 'flex-start',
                      alignItems: 'flex-start',
                      fontFamily: 'Poppins',
                      fontSize: 10,
                      fontWeight: '600',
                      lineHeight: 11,
                      color: '#000000',
                      position: 'absolute',
                      top: 4,
                      left: '50%',
                      textAlign: 'left',
                      zIndex: 29,
                      transform: [{ translateX: -15.5 }],
                    }}
                    numberOfLines={1}
                  >
                    Lokasi
                  </Text>
                </View>
              </View>
            </View>
            <ImageBackground
              style={{
                width: 361,
                height: 1,
                position: 'relative',
                zIndex: 59,
                marginTop: 17,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/8b2ef0a7-43a7-40b9-af90-9fc3277b99a3.png')}
              resizeMode='cover'
            />
            <Text
              style={{
                display: 'flex',
                height: 22,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 15,
                fontWeight: '600',
                lineHeight: 22,
                color: '#052844',
                position: 'absolute',
                top: 11,
                left: '50%',
                textAlign: 'left',
                zIndex: 6,
                transform: [{ translateX: -165.5 }],
              }}
              numberOfLines={1}
            >
              Catatan
            </Text>
            <ImageBackground
              style={{
                width: '4.71%',
                height: '3.59%',
                position: 'absolute',
                top: '3.38%',
                left: '91.41%',
                zIndex: 63,
              }}
              source={require('./assets/images/41446daa-6d8a-4157-8158-b591b0d41719.png')}
            />
          </View>
          <View
            style={{
              width: 430,
              height: 99,
              backgroundColor: '#e8e8e8',
              position: 'relative',
              zIndex: 64,
              marginTop: 10,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <ImageBackground
              style={{
                width: 100,
                height: 100,
                position: 'absolute',
                top: -1,
                left: 165,
                zIndex: 74,
              }}
              source={require('./assets/images/14dc9280eaccb926918988171520701546b792e5.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 349,
                zIndex: 67,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 4,
                  position: 'relative',
                  zIndex: 69,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 15,
                }}
                source={require('./assets/images/4ad58462-4b22-46c3-aeec-8d7285079cc3.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 277,
                zIndex: 71,
              }}
            >
              <ImageBackground
                style={{
                  width: 20.1,
                  height: 20,
                  position: 'relative',
                  zIndex: 73,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 13.95,
                }}
                source={require('./assets/images/f111f628-9930-4871-a5e9-b1e624294a42.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 105,
                zIndex: 76,
              }}
            >
              <View
                style={{
                  width: 28,
                  height: 24,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 77,
                  marginTop: 9,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 26.333,
                    height: 23,
                    position: 'relative',
                    zIndex: 78,
                    marginTop: 0.5,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 0.83,
                  }}
                  source={require('./assets/images/db78daa7-d72c-469a-808d-9c5d8290df59.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 33,
                zIndex: 80,
              }}
            >
              <View
                style={{
                  width: 30,
                  height: 28,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 81,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 28.86,
                    height: 27.083,
                    position: 'relative',
                    zIndex: 82,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 1.14,
                  }}
                  source={require('./assets/images/a7fda42d-7d17-4218-9ed1-5bde8339364c.png')}
                />
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            backgroundColor: '#f5f6f8',
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            borderBottomRightRadius: 35,
            borderBottomLeftRadius: 35,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <ImageBackground
            style={{
              width: 421,
              height: 30,
              position: 'relative',
              zIndex: 12,
              marginTop: 7,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 6,
            }}
            source={require('./assets/images/68c4decd-df3e-4fe6-b76b-80ccaeedf2fd.png')}
            resizeMode='cover'
          />
          <Text
            style={{
              height: 35,
              fontFamily: 'Poppins',
              fontSize: 26,
              fontWeight: '600',
              lineHeight: 35,
              color: '#052844',
              position: 'relative',
              textAlign: 'left',
              zIndex: 5,
              marginTop: 42,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 101,
            }}
            numberOfLines={1}
          >
            Catatan Nelayan
          </Text>
          <Text
            style={{
              height: 17,
              fontFamily: 'Poppins',
              fontSize: 12,
              fontWeight: '600',
              lineHeight: 17,
              color: '#052844',
              position: 'relative',
              textAlign: 'left',
              zIndex: 11,
              marginTop: 0,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 157,
            }}
            numberOfLines={1}
          >
            11 September 2024
          </Text>
          <View
            style={{
              width: 361,
              height: 112,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              marginTop: 34,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <View
              style={{
                width: 90,
                height: 91,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 11,
                left: 10,
                zIndex: 41,
              }}
            >
              <View
                style={{
                  width: 50,
                  height: 50,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 42,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 20,
                }}
              >
                <ImageBackground
                  style={{
                    width: 45.667,
                    height: 45.667,
                    position: 'relative',
                    zIndex: 43,
                    marginTop: 2.167,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 2.167,
                  }}
                  source={require('./assets/images/4432210a-b966-46ac-a47e-adb845d6ed04.png')}
                />
              </View>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 35,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 20,
                fontWeight: '600',
                lineHeight: 30,
                color: '#052844',
                position: 'absolute',
                top: 39,
                left: '50%',
                textAlign: 'left',
                zIndex: 6,
                transform: [{ translateX: -57.5 }],
              }}
              numberOfLines={1}
            >
              Ada Pertanyaan?
            </Text>
          </View>
          <View
            style={{
              width: 361,
              height: 112,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              zIndex: 1,
              marginTop: 23,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <View
              style={{
                width: 90,
                height: 91,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 11,
                left: 10,
                zIndex: 37,
              }}
            >
              <View
                style={{
                  width: 48,
                  height: 48,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 38,
                  marginTop: 22,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 18,
                }}
              >
                <ImageBackground
                  style={{
                    width: 45.776,
                    height: 45.856,
                    position: 'relative',
                    zIndex: 39,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 2.224,
                  }}
                  source={require('./assets/images/cb3076a0-7e87-41b9-8422-775b9f8e3332.png')}
                />
              </View>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 35,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 20,
                fontWeight: '600',
                lineHeight: 30,
                color: '#052844',
                position: 'absolute',
                top: 39,
                left: '50%',
                textAlign: 'left',
                zIndex: 7,
                transform: [{ translateX: -57.5 }],
              }}
              numberOfLines={1}
            >
              Hubungi Kami
            </Text>
          </View>
          <View
            style={{
              width: 361,
              height: 112,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              zIndex: 2,
              marginTop: 23,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <View
              style={{
                width: 90,
                height: 91,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 11,
                left: 10,
                zIndex: 46,
              }}
            >
              <ImageBackground
                style={{
                  width: 41.667,
                  height: 33.333,
                  position: 'relative',
                  zIndex: 48,
                  marginTop: 28.333,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 24.167,
                }}
                source={require('./assets/images/1a63ecfe-8f73-4909-ba06-66b7faedd64f.png')}
              />
            </View>
            <Text
              style={{
                display: 'flex',
                height: 35,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 20,
                fontWeight: '600',
                lineHeight: 30,
                color: '#052844',
                position: 'absolute',
                top: 39,
                left: '50%',
                textAlign: 'left',
                zIndex: 8,
                transform: [{ translateX: -57.5 }],
              }}
              numberOfLines={1}
            >
              Penjelasan
            </Text>
          </View>
          <View
            style={{
              width: 361,
              height: 112,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              zIndex: 3,
              marginTop: 23,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <View
              style={{
                width: 90,
                height: 91,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 11,
                left: 10,
                zIndex: 50,
              }}
            >
              <View
                style={{
                  width: 48,
                  height: 48,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 51,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 22,
                }}
              >
                <ImageBackground
                  style={{
                    width: 48,
                    height: 40,
                    position: 'relative',
                    zIndex: 52,
                    marginTop: 4,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 0,
                  }}
                  source={require('./assets/images/e1399f4d-b878-4f94-aa3a-68d831fe9b06.png')}
                />
              </View>
            </View>
            <Text
              style={{
                display: 'flex',
                height: 35,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 20,
                fontWeight: '600',
                lineHeight: 30,
                color: '#052844',
                position: 'absolute',
                top: 39,
                left: '50%',
                textAlign: 'left',
                zIndex: 9,
                transform: [{ translateX: -57.5 }],
              }}
              numberOfLines={1}
            >
              Profile Kami
            </Text>
          </View>
          <View
            style={{
              width: 361,
              height: 112,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'relative',
              zIndex: 4,
              marginTop: 23,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 34,
            }}
          >
            <View
              style={{
                width: 90,
                height: 91,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 11,
                left: 10,
                zIndex: 33,
              }}
            >
              <ImageBackground
                style={{
                  width: 41.875,
                  height: 41.667,
                  position: 'relative',
                  zIndex: 35,
                  marginTop: 24.167,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 24.063,
                }}
                source={require('./assets/images/7de81000-d38c-4341-aca6-fab87d6ab443.png')}
              />
            </View>
            <Text
              style={{
                display: 'flex',
                height: 35,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 20,
                fontWeight: '600',
                lineHeight: 30,
                color: '#052844',
                position: 'absolute',
                top: 39,
                left: '50%',
                textAlign: 'left',
                zIndex: 10,
                transform: [{ translateX: -57.5 }],
              }}
              numberOfLines={1}
            >
              Pengaturan
            </Text>
          </View>
          <View
            style={{
              width: 430,
              height: 99,
              backgroundColor: '#e8e8e8',
              position: 'relative',
              zIndex: 13,
              marginTop: 16,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <ImageBackground
              style={{
                width: 100,
                height: 100,
                position: 'absolute',
                top: -1,
                left: 165,
                zIndex: 23,
              }}
              source={require('./assets/images/14dc9280eaccb926918988171520701546b792e5.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 349,
                zIndex: 16,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 4,
                  position: 'relative',
                  zIndex: 18,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 15,
                }}
                source={require('./assets/images/bbd4da2c-b86e-4be8-849f-b5642c201e4e.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 277,
                zIndex: 20,
              }}
            >
              <ImageBackground
                style={{
                  width: 20.1,
                  height: 20,
                  position: 'relative',
                  zIndex: 22,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 13.95,
                }}
                source={require('./assets/images/cfa947c1-7a3d-44ba-ad90-2c105b0edbe1.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 105,
                zIndex: 25,
              }}
            >
              <View
                style={{
                  width: 28,
                  height: 24,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 26,
                  marginTop: 9,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 26.333,
                    height: 23,
                    position: 'relative',
                    zIndex: 27,
                    marginTop: 0.5,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 0.83,
                  }}
                  source={require('./assets/images/df00d492-2c4f-4746-9489-fb659c1c7692.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 33,
                zIndex: 29,
              }}
            >
              <View
                style={{
                  width: 30,
                  height: 28,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 30,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 28.86,
                    height: 27.083,
                    position: 'relative',
                    zIndex: 31,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 1.14,
                  }}
                  source={require('./assets/images/16da152f-3a2f-4efd-af86-1392284f3b15.png')}
                />
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            backgroundColor: '#f5f6f8',
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            borderBottomRightRadius: 35,
            borderBottomLeftRadius: 35,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <View
            style={{
              width: 433,
              height: 43,
              backgroundColor: 'rgba(232, 232, 232, 0.75)',
              position: 'relative',
              zIndex: 20,
              marginTop: 37,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <View
              style={{
                width: 24,
                height: 24,
                backgroundColor: '#e8e8e8',
                borderTopLeftRadius: 6,
                borderTopRightRadius: 6,
                borderBottomRightRadius: 6,
                borderBottomLeftRadius: 6,
                position: 'absolute',
                top: 10,
                left: 13,
                zIndex: 21,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 16,
                  position: 'relative',
                  zIndex: 22,
                  marginTop: 4,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 4,
                }}
                source={require('./assets/images/1d3fc695-8da5-43e3-ae08-bbb1babc2449.png')}
              />
            </View>
            <Text
              style={{
                display: 'flex',
                width: 115,
                height: 22,
                justifyContent: 'center',
                alignItems: 'flex-start',
                fontFamily: 'Roboto',
                fontSize: 16,
                fontWeight: '500',
                lineHeight: 22,
                color: '#052844',
                letterSpacing: 0.15,
                position: 'absolute',
                top: 12,
                left: 160,
                textAlign: 'center',
                zIndex: 23,
              }}
              numberOfLines={1}
            >
              Detail
            </Text>
          </View>
          <View
            style={{
              width: 409,
              height: 299,
              backgroundColor: '#ffffff',
              borderTopLeftRadius: 5,
              borderTopRightRadius: 5,
              borderBottomRightRadius: 5,
              borderBottomLeftRadius: 5,
              position: 'relative',
              zIndex: 3,
              marginTop: 427,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 13,
            }}
          >
            <View
              style={{
                width: 388,
                height: 42,
                position: 'relative',
                zIndex: 8,
                marginTop: 14,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 10,
              }}
            >
              <View
                style={{
                  width: 42,
                  height: 42,
                  backgroundColor: '#e8e8e8',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 4,
                }}
              />
              <Text
                style={{
                  display: 'flex',
                  height: 24,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 16,
                  fontWeight: '600',
                  lineHeight: 24,
                  color: '#052844',
                  position: 'absolute',
                  top: 8,
                  left: '50%',
                  textAlign: 'left',
                  zIndex: 5,
                  transform: [{ translateX: -139 }],
                }}
                numberOfLines={1}
              >
                Jaring
              </Text>
              <Text
                style={{
                  display: 'flex',
                  height: 18,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 12,
                  fontWeight: '600',
                  lineHeight: 18,
                  color: '#525252',
                  position: 'absolute',
                  top: 13,
                  left: '50%',
                  textAlign: 'left',
                  zIndex: 6,
                  transform: [{ translateX: -80 }],
                }}
                numberOfLines={1}
              >
                | Ikan Tuna
              </Text>
              <Text
                style={{
                  display: 'flex',
                  height: 14,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 14,
                  color: '#525151',
                  position: 'absolute',
                  top: 15,
                  textAlign: 'left',
                  zIndex: 8,
                }}
                numberOfLines={1}
              >
                Setiap 7 Hari
              </Text>
            </View>
            <ImageBackground
              style={{
                width: 409,
                height: 1,
                position: 'relative',
                zIndex: 18,
                marginTop: 16,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/8812c42a-6b37-445f-a98f-58682aa4c2e5.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 385,
                height: 77,
                position: 'relative',
                zIndex: 14,
                marginTop: 17,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 11,
              }}
            >
              <Text
                style={{
                  display: 'flex',
                  width: 261,
                  height: 77,
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 7,
                  fontWeight: '400',
                  lineHeight: 10.5,
                  color: '#525151',
                  position: 'absolute',
                  top: 0,
                  left: '50%',
                  zIndex: 14,
                  transform: [{ translateX: -192.5 }],
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
              </Text>
              <Text
                style={{
                  display: 'flex',
                  height: 13,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Poppins',
                  fontSize: 8,
                  fontWeight: '600',
                  lineHeight: 12,
                  color: '#525151',
                  position: 'absolute',
                  top: 0,
                  textAlign: 'left',
                  zIndex: 9,
                }}
                numberOfLines={1}
              >
                3 Jam 16 menit 20 detik
              </Text>
            </View>
            <View
              style={{
                display: 'flex',
                width: 263,
                height: 13,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                position: 'relative',
                zIndex: 13,
                marginTop: 13,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 11,
              }}
            >
              <Text
                style={{
                  height: 13,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 13,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 10,
                }}
                numberOfLines={1}
              >
                19310 meter
              </Text>
              <Text
                style={{
                  height: 13,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 13,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 11,
                }}
                numberOfLines={1}
              >
                1.4 Liter / Jam
              </Text>
              <Text
                style={{
                  height: 13,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 13,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 12,
                }}
                numberOfLines={1}
              >
                1.93 Jam
              </Text>
              <Text
                style={{
                  height: 13,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 13,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 13,
                }}
                numberOfLines={1}
              >
                Rp 32.400
              </Text>
            </View>
            <View
              style={{
                display: 'flex',
                width: 206.072,
                height: 31.073,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                position: 'relative',
                zIndex: 16,
                marginTop: 66.821,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 198,
              }}
            >
              <Text
                style={{
                  height: 11,
                  flexShrink: 0,
                  fontFamily: 'Poppins',
                  fontSize: 10,
                  fontWeight: '600',
                  lineHeight: 11,
                  color: '#525151',
                  position: 'relative',
                  textAlign: 'left',
                  zIndex: 7,
                }}
                numberOfLines={1}
              >
                -6.081, 106.895
              </Text>
              <View
                style={{
                  width: 80.075,
                  height: 31.073,
                  flexShrink: 0,
                  backgroundColor: '#b5e4ff',
                  borderTopLeftRadius: 5,
                  borderTopRightRadius: 5,
                  borderBottomRightRadius: 5,
                  borderBottomLeftRadius: 5,
                  position: 'relative',
                  zIndex: 16,
                }}
              >
                <Text
                  style={{
                    display: 'flex',
                    height: 14.861,
                    justifyContent: 'flex-start',
                    alignItems: 'flex-start',
                    fontFamily: 'Poppins',
                    fontSize: 10,
                    fontWeight: '600',
                    lineHeight: 14.861,
                    color: '#052844',
                    position: 'absolute',
                    top: 8.179,
                    left: '50%',
                    textAlign: 'left',
                    zIndex: 17,
                    transform: [{ translateX: -22.03 }],
                  }}
                  numberOfLines={1}
                >
                  Kembali
                </Text>
              </View>
            </View>
          </View>
          <View
            style={{
              width: 430,
              height: 99,
              backgroundColor: '#e8e8e8',
              position: 'relative',
              zIndex: 24,
              marginTop: 27,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <ImageBackground
              style={{
                width: 100,
                height: 100,
                position: 'absolute',
                top: -1,
                left: 165,
                zIndex: 34,
              }}
              source={require('./assets/images/14dc9280eaccb926918988171520701546b792e5.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 349,
                zIndex: 27,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 4,
                  position: 'relative',
                  zIndex: 29,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 15,
                }}
                source={require('./assets/images/2d92cedd-82c8-4a13-8467-9381377f7246.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 277,
                zIndex: 31,
              }}
            >
              <ImageBackground
                style={{
                  width: 20.1,
                  height: 20,
                  position: 'relative',
                  zIndex: 33,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 13.95,
                }}
                source={require('./assets/images/b83d655d-01e7-4710-a12e-0549a49d82a6.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 105,
                zIndex: 36,
              }}
            >
              <View
                style={{
                  width: 28,
                  height: 24,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 37,
                  marginTop: 9,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 26.333,
                    height: 23,
                    position: 'relative',
                    zIndex: 38,
                    marginTop: 0.5,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 0.83,
                  }}
                  source={require('./assets/images/0d1984a5-2669-4162-a69c-b96a86daf4bd.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 33,
                zIndex: 40,
              }}
            >
              <View
                style={{
                  width: 30,
                  height: 28,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 41,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 28.86,
                    height: 27.083,
                    position: 'relative',
                    zIndex: 42,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 1.14,
                  }}
                  source={require('./assets/images/2b01a93c-2abf-49da-884f-7d7186b9e8b6.png')}
                />
              </View>
            </View>
          </View>
          <ImageBackground
            style={{
              width: 465,
              height: 940,
              position: 'absolute',
              top: -8,
              left: -18,
            }}
            source={require('./assets/images/4e51838b86ad03c8f48ee8401b97e46006342511.png')}
            resizeMode='cover'
          />
          <ImageBackground
            style={{
              width: 433,
              height: 37,
              position: 'absolute',
              top: 0,
              left: 0,
              zIndex: 1,
            }}
            source={require('./assets/images/40d842ef-51e5-403f-a57e-198f16494c91.png')}
            resizeMode='cover'
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

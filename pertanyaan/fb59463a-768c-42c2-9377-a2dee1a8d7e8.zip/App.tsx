/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            backgroundColor: '#f5f6f8',
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            borderBottomRightRadius: 35,
            borderBottomLeftRadius: 35,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <ImageBackground
            style={{
              width: 421,
              height: 30,
              position: 'relative',
              marginTop: 7,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 6,
            }}
            source={require('./assets/images/54b09548-951b-42e2-8bea-594c1e7062a7.png')}
            resizeMode='cover'
          />
          <View
            style={{
              width: 433,
              height: 43,
              backgroundColor: 'rgba(232, 232, 232, 0.75)',
              position: 'relative',
              zIndex: 2,
              marginTop: 12,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <View
              style={{
                width: 24,
                height: 24,
                backgroundColor: '#e8e8e8',
                borderTopLeftRadius: 6,
                borderTopRightRadius: 6,
                borderBottomRightRadius: 6,
                borderBottomLeftRadius: 6,
                position: 'absolute',
                top: 10,
                left: 13,
                zIndex: 3,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 16,
                  position: 'relative',
                  zIndex: 4,
                  marginTop: 4,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 4,
                }}
                source={require('./assets/images/24d05353-8e26-44b2-9a93-83aa852fc230.png')}
              />
            </View>
            <Text
              style={{
                display: 'flex',
                width: 115,
                height: 22,
                justifyContent: 'center',
                alignItems: 'flex-start',
                fontFamily: 'Roboto',
                fontSize: 16,
                fontWeight: '500',
                lineHeight: 22,
                color: '#052844',
                letterSpacing: 0.15,
                position: 'absolute',
                top: 12,
                left: 160,
                textAlign: 'center',
                zIndex: 5,
              }}
              numberOfLines={1}
            >
              Pertanyaan
            </Text>
          </View>
          <Text
            style={{
              display: 'flex',
              width: 256,
              height: 35,
              justifyContent: 'center',
              alignItems: 'flex-start',
              fontFamily: 'Poppins',
              fontSize: 26,
              fontWeight: '600',
              lineHeight: 35,
              color: '#052844',
              position: 'relative',
              textAlign: 'center',
              zIndex: 6,
              marginTop: 36,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 91,
            }}
            numberOfLines={1}
          >
            Ada Pertanyaan?
          </Text>
          <Text
            style={{
              height: 17,
              fontFamily: 'Poppins',
              fontSize: 12,
              fontWeight: '600',
              lineHeight: 17,
              color: '#052844',
              position: 'relative',
              textAlign: 'left',
              zIndex: 7,
              marginTop: 0,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 160,
            }}
            numberOfLines={1}
          >
            11 September 2024
          </Text>
          <View
            style={{
              width: 430,
              height: 99,
              backgroundColor: '#e8e8e8',
              position: 'relative',
              zIndex: 34,
              marginTop: 653,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 0,
            }}
          >
            <ImageBackground
              style={{
                width: 100,
                height: 100,
                position: 'absolute',
                top: -1,
                left: 165,
                zIndex: 44,
              }}
              source={require('./assets/images/14dc9280eaccb926918988171520701546b792e5.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 349,
                zIndex: 37,
              }}
            >
              <ImageBackground
                style={{
                  width: 16,
                  height: 4,
                  position: 'relative',
                  zIndex: 39,
                  marginTop: 20,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 15,
                }}
                source={require('./assets/images/7d96491a-51c1-465d-b4fe-35512ab71e30.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 24,
                left: 277,
                zIndex: 41,
              }}
            >
              <ImageBackground
                style={{
                  width: 20.1,
                  height: 20,
                  position: 'relative',
                  zIndex: 43,
                  marginTop: 12,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 13.95,
                }}
                source={require('./assets/images/ac48262b-a673-4d01-8577-065b13a270e2.png')}
              />
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 105,
                zIndex: 46,
              }}
            >
              <View
                style={{
                  width: 28,
                  height: 24,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 47,
                  marginTop: 9,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 26.333,
                    height: 23,
                    position: 'relative',
                    zIndex: 48,
                    marginTop: 0.5,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 0.83,
                  }}
                  source={require('./assets/images/a315d13f-4503-43dc-90c5-78fe308bb7c2.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: 48,
                height: 44,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'absolute',
                top: 28,
                left: 33,
                zIndex: 50,
              }}
            >
              <View
                style={{
                  width: 30,
                  height: 28,
                  position: 'relative',
                  overflow: 'hidden',
                  zIndex: 51,
                  marginTop: 8,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 10,
                }}
              >
                <ImageBackground
                  style={{
                    width: 28.86,
                    height: 27.083,
                    position: 'relative',
                    zIndex: 52,
                    marginTop: 0,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 1.14,
                  }}
                  source={require('./assets/images/dfd62fe8-9442-4191-a367-e627392c5b58.png')}
                />
              </View>
            </View>
          </View>
          <View
            style={{
              width: 358,
              height: 578,
              backgroundColor: '#e8e8e8',
              borderTopLeftRadius: 11,
              borderTopRightRadius: 11,
              borderBottomRightRadius: 11,
              borderBottomLeftRadius: 11,
              position: 'absolute',
              top: 216,
              left: 38,
              zIndex: 9,
            }}
          >
            <View
              style={{
                width: 302,
                height: 75,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'relative',
                zIndex: 14,
                marginTop: 27,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 26,
              }}
            >
              <Text
                style={{
                  display: 'flex',
                  width: 233,
                  height: 36,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Roboto',
                  fontSize: 12,
                  fontWeight: '400',
                  lineHeight: 16,
                  color: '#052844',
                  letterSpacing: 0.4,
                  position: 'absolute',
                  top: 20,
                  left: 10,
                  textAlign: 'left',
                  zIndex: 17,
                }}
              >
                Mengapa saya tidak bisa menambahkan catatan?&nbsp;
              </Text>
              <View
                style={{
                  width: 24,
                  height: 24,
                  backgroundColor: '#f5f6f8',
                  borderTopLeftRadius: 6,
                  borderTopRightRadius: 6,
                  borderBottomRightRadius: 6,
                  borderBottomLeftRadius: 6,
                  position: 'absolute',
                  top: 26,
                  left: 259,
                  zIndex: 15,
                }}
              >
                <ImageBackground
                  style={{
                    width: 5,
                    height: 10,
                    position: 'relative',
                    zIndex: 16,
                    marginTop: 7,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 10,
                  }}
                  source={require('./assets/images/39ed1bb5-7c0f-429a-8cff-cbaee564634c.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: 358.003,
                height: 2,
                position: 'relative',
                zIndex: 10,
                marginTop: 26,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/cc046e7a-9d28-42b4-8d3a-e383cd2736de.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 302,
                height: 75,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'relative',
                zIndex: 20,
                marginTop: 27,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 28,
              }}
            >
              <Text
                style={{
                  display: 'flex',
                  width: 233,
                  height: 36,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Roboto',
                  fontSize: 12,
                  fontWeight: '400',
                  lineHeight: 16,
                  color: '#052844',
                  letterSpacing: 0.4,
                  position: 'absolute',
                  top: 21,
                  left: 12,
                  textAlign: 'left',
                  zIndex: 23,
                }}
              >
                Mengapa saya tidak bisa mengedit catatan?&nbsp;
              </Text>
              <View
                style={{
                  width: 24,
                  height: 24,
                  backgroundColor: '#f5f6f8',
                  borderTopLeftRadius: 6,
                  borderTopRightRadius: 6,
                  borderBottomRightRadius: 6,
                  borderBottomLeftRadius: 6,
                  position: 'absolute',
                  top: 25,
                  left: 260,
                  zIndex: 21,
                }}
              >
                <ImageBackground
                  style={{
                    width: 5,
                    height: 10,
                    position: 'relative',
                    zIndex: 22,
                    marginTop: 7,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 10,
                  }}
                  source={require('./assets/images/1cf51a91-a54c-452f-9bc7-c9cdf11bc40b.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: 302,
                height: 114,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'relative',
                zIndex: 25,
                marginTop: 55,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 28,
              }}
            >
              <Text
                style={{
                  display: 'flex',
                  width: 233,
                  height: 73,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Roboto',
                  fontSize: 12,
                  fontWeight: '400',
                  lineHeight: 16,
                  color: '#052844',
                  letterSpacing: 0.4,
                  position: 'absolute',
                  top: 25,
                  left: 12,
                  textAlign: 'left',
                  zIndex: 28,
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam?&nbsp;
              </Text>
              <View
                style={{
                  width: 24,
                  height: 24,
                  backgroundColor: '#f5f6f8',
                  borderTopLeftRadius: 6,
                  borderTopRightRadius: 6,
                  borderBottomRightRadius: 6,
                  borderBottomLeftRadius: 6,
                  position: 'absolute',
                  top: 45,
                  left: 263,
                  zIndex: 26,
                }}
              >
                <ImageBackground
                  style={{
                    width: 5,
                    height: 10,
                    position: 'relative',
                    zIndex: 27,
                    marginTop: 7,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 10,
                  }}
                  source={require('./assets/images/4a1e61ce-4ca8-4c35-b60d-5253a4ee97da.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: 358.003,
                height: 2,
                position: 'relative',
                zIndex: 12,
                marginTop: 26.5,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 0,
              }}
              source={require('./assets/images/e2a71237-e540-47a7-84de-829821a67441.png')}
              resizeMode='cover'
            />
            <View
              style={{
                width: 302,
                height: 95,
                backgroundColor: '#ffffff',
                borderTopLeftRadius: 11,
                borderTopRightRadius: 11,
                borderBottomRightRadius: 11,
                borderBottomLeftRadius: 11,
                position: 'relative',
                zIndex: 30,
                marginTop: 26.5,
                marginRight: 0,
                marginBottom: 0,
                marginLeft: 26,
              }}
            >
              <Text
                style={{
                  display: 'flex',
                  width: 233,
                  height: 64,
                  justifyContent: 'flex-start',
                  alignItems: 'flex-start',
                  fontFamily: 'Roboto',
                  fontSize: 12,
                  fontWeight: '400',
                  lineHeight: 16,
                  color: '#052844',
                  letterSpacing: 0.4,
                  position: 'absolute',
                  top: 15,
                  left: 13,
                  textAlign: 'left',
                  zIndex: 33,
                }}
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna
                aliqua?&nbsp;
              </Text>
              <View
                style={{
                  width: 24,
                  height: 24,
                  backgroundColor: '#f5f6f8',
                  borderTopLeftRadius: 6,
                  borderTopRightRadius: 6,
                  borderBottomRightRadius: 6,
                  borderBottomLeftRadius: 6,
                  position: 'absolute',
                  top: 36,
                  left: 265,
                  zIndex: 31,
                }}
              >
                <ImageBackground
                  style={{
                    width: 5,
                    height: 10,
                    position: 'relative',
                    zIndex: 32,
                    marginTop: 7,
                    marginRight: 0,
                    marginBottom: 0,
                    marginLeft: 10,
                  }}
                  source={require('./assets/images/b97e6f97-3b88-461c-8ca0-81a8fc3b62bc.png')}
                />
              </View>
            </View>
          </View>
          <ImageBackground
            style={{
              width: 358.003,
              height: 2,
              position: 'absolute',
              top: 474.5,
              left: 39.999,
              zIndex: 11,
            }}
            source={require('./assets/images/57b25faf-d2ae-4329-9df7-7cea7abb0ace.png')}
            resizeMode='cover'
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

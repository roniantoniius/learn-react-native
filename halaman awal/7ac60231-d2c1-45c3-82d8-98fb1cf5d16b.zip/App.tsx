/**
 * Codia React Native App
 * https://codia.ai
 * https://github.com/facebook/react-native
 *
 * @format
 */
import React from 'react';
import {
  View,
  Text,
  ImageBackground,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function App(): React.JSX.Element {
  return (
    <SafeAreaView>
      <ScrollView
        scrollEnabled={true}
        contentInsetAdjustmentBehavior='automatic'
      >
        <View
          style={{
            width: 430,
            height: 932,
            backgroundColor: '#052844',
            borderTopLeftRadius: 35,
            borderTopRightRadius: 35,
            borderBottomRightRadius: 35,
            borderBottomLeftRadius: 35,
            position: 'relative',
            overflow: 'hidden',
            marginTop: 0,
            marginRight: 'auto',
            marginBottom: 0,
            marginLeft: 'auto',
          }}
        >
          <View
            style={{
              width: 327,
              height: 327,
              position: 'relative',
              overflow: 'hidden',
              zIndex: 5,
              marginTop: 139,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 52,
            }}
          >
            <View
              style={{
                width: '120%',
                height: '120%',
                position: 'absolute',
                top: '-10%',
                left: '-10%',
                zIndex: 89,
              }}
            >
              <View
                style={{
                  width: 208.408,
                  height: 11.336,
                  position: 'relative',
                  zIndex: 90,
                  marginTop: 287.324,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 91.996,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 91,
                  }}
                >
                  <View
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 92,
                    }}
                  >
                    <View
                      style={{
                        width: 208.023,
                        height: 10.239,
                        position: 'relative',
                        zIndex: 93,
                        marginTop: 0.92,
                        marginRight: 0,
                        marginBottom: 0,
                        marginLeft: 0.14,
                      }}
                    >
                      <View
                        style={{
                          width: '100%',
                          height: '100%',
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          zIndex: 94,
                        }}
                      >
                        <View
                          style={{
                            width: 207.618,
                            height: 10.173,
                            position: 'relative',
                            zIndex: 95,
                            marginTop: 0.02,
                            marginRight: 0,
                            marginBottom: 0,
                            marginLeft: 0.11,
                          }}
                        >
                          <ImageBackground
                            style={{
                              width: '100%',
                              height: '100%',
                              position: 'absolute',
                              top: 0,
                              left: 0,
                              zIndex: 96,
                            }}
                            source={require('./assets/images/54939368-3a22-439c-9041-5b8ad8b51eaa.png')}
                          />
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </View>
            <View
              style={{
                width: '76.2%',
                height: '76.2%',
                position: 'absolute',
                top: '10.17%',
                left: '11.86%',
                zIndex: 6,
              }}
            >
              <View
                style={{
                  width: '100.11%',
                  height: '100.11%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 7,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 8,
                  }}
                  source={require('./assets/images/1591f2df-e479-417b-b616-3ea0f68f5add.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: '57.16%',
                height: '44.27%',
                position: 'absolute',
                top: '16.53%',
                left: '16.44%',
                zIndex: 49,
              }}
            >
              <View
                style={{
                  width: 186.442,
                  height: 143.336,
                  position: 'relative',
                  zIndex: 50,
                  marginTop: 0.65,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.18,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 51,
                  }}
                  source={require('./assets/images/e6b4ee8c-0295-4024-a242-16d1d04997d6.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: '2.24%',
                height: '2.52%',
                position: 'absolute',
                top: '20.16%',
                left: '46.02%',
                zIndex: 29,
              }}
              source={require('./assets/images/bc248ab8-347d-4755-8a5d-77d1dce792e0.png')}
            />
            <ImageBackground
              style={{
                width: '2.62%',
                height: '2.41%',
                position: 'absolute',
                top: '20.54%',
                left: '42.53%',
                zIndex: 31,
              }}
              source={require('./assets/images/ee2c3edf-7b44-4be4-a102-290105f38236.png')}
            />
            <ImageBackground
              style={{
                width: '1.43%',
                height: '0.96%',
                position: 'absolute',
                top: '32.55%',
                left: '40.87%',
                zIndex: 27,
              }}
              source={require('./assets/images/071be9b8-5668-4fb0-b630-9eae5918622e.png')}
            />
            <ImageBackground
              style={{
                width: '21.92%',
                height: '22.64%',
                position: 'absolute',
                top: '34.28%',
                left: '49.97%',
                zIndex: 13,
              }}
              source={require('./assets/images/9396265b-ece7-4d20-8b26-326d94924d11.png')}
            />
            <ImageBackground
              style={{
                width: '3.31%',
                height: '2.16%',
                position: 'absolute',
                top: '46.12%',
                left: '43.06%',
                zIndex: 12,
              }}
              source={require('./assets/images/01f264f6-e00e-4df1-9af2-16b5fe51aa1d.png')}
            />
            <ImageBackground
              style={{
                width: '1.32%',
                height: '2.84%',
                position: 'absolute',
                top: '47.81%',
                left: '29.96%',
                zIndex: 18,
              }}
              source={require('./assets/images/f1279f5e-1309-4c33-9b1b-6818679ccc36.png')}
            />
            <ImageBackground
              style={{
                width: '1.47%',
                height: '2.82%',
                position: 'absolute',
                top: '47.81%',
                left: '31.74%',
                zIndex: 24,
              }}
              source={require('./assets/images/3d6e26c7-d0f9-448a-ba4c-3e429331b4fb.png')}
            />
            <ImageBackground
              style={{
                width: '1.36%',
                height: '2.96%',
                position: 'absolute',
                top: '47.96%',
                left: '35.5%',
                zIndex: 11,
              }}
              source={require('./assets/images/bb53142e-2472-4821-bfdc-4cce486944cd.png')}
            />
            <ImageBackground
              style={{
                width: '1.72%',
                height: '3.18%',
                position: 'absolute',
                top: '48%',
                left: '37.48%',
                zIndex: 10,
              }}
              source={require('./assets/images/ba3af1ab-2317-447e-9053-e4a95fe8a95a.png')}
            />
            <ImageBackground
              style={{
                width: '1.6%',
                height: '3.35%',
                position: 'absolute',
                top: '48.1%',
                left: '39.52%',
                zIndex: 25,
              }}
              source={require('./assets/images/707ae7ac-9e26-4c8d-82fa-8f74095a4847.png')}
            />
            <ImageBackground
              style={{
                width: '5.4%',
                height: '4.19%',
                position: 'absolute',
                top: '48.26%',
                left: '41.33%',
                zIndex: 26,
              }}
              source={require('./assets/images/a24d399f-5a33-43ef-af3f-b06a08e4949b.png')}
            />
            <ImageBackground
              style={{
                width: '21.7%',
                height: '2.76%',
                position: 'absolute',
                top: '51.42%',
                left: '25.97%',
                zIndex: 17,
              }}
              source={require('./assets/images/d6a94627-e58f-4859-a622-569359fc1727.png')}
            />
            <ImageBackground
              style={{
                width: '2.44%',
                height: '2.68%',
                position: 'absolute',
                top: '51.69%',
                left: '74.02%',
                zIndex: 46,
              }}
              source={require('./assets/images/ec412395-70ef-4521-9413-4fe376d1af11.png')}
            />
            <ImageBackground
              style={{
                width: '1.51%',
                height: '2.54%',
                position: 'absolute',
                top: '51.74%',
                left: '72.35%',
                zIndex: 45,
              }}
              source={require('./assets/images/ffc853c8-0c0c-40a3-9e3c-a5b5bc1e9634.png')}
            />
            <ImageBackground
              style={{
                width: '1.73%',
                height: '2.37%',
                position: 'absolute',
                top: '51.84%',
                left: '76.58%',
                zIndex: 48,
              }}
              source={require('./assets/images/a3942f9e-101c-4ff0-a7aa-79b68f630797.png')}
            />
            <ImageBackground
              style={{
                width: '2.17%',
                height: '2.2%',
                position: 'absolute',
                top: '51.87%',
                left: '67.69%',
                zIndex: 47,
              }}
              source={require('./assets/images/e7895d90-61bd-4db1-90d4-1b8c6ea386fc.png')}
            />
            <ImageBackground
              style={{
                width: '1.4%',
                height: '1.79%',
                position: 'absolute',
                top: '52.38%',
                left: '65.63%',
                zIndex: 42,
              }}
              source={require('./assets/images/7224c6ee-772c-4515-aa9a-ade58827e76f.png')}
            />
            <ImageBackground
              style={{
                width: '22.76%',
                height: '4.13%',
                position: 'absolute',
                top: '52.47%',
                left: '25.34%',
                zIndex: 15,
              }}
              source={require('./assets/images/d0308b94-77a5-4f8d-9f10-3375b4c35fd7.png')}
            />
            <View
              style={{
                width: '2.23%',
                height: '2.4%',
                position: 'absolute',
                top: '52.8%',
                left: '16.44%',
                zIndex: 38,
              }}
            >
              <View
                style={{
                  width: 6.942,
                  height: 6.802,
                  position: 'relative',
                  zIndex: 39,
                  marginTop: 0.79,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.03,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 40,
                  }}
                  source={require('./assets/images/388ec43c-6f9a-4621-878b-b1e2c456c16f.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: '1.78%',
                height: '1.43%',
                position: 'absolute',
                top: '52.8%',
                left: '63.02%',
                zIndex: 44,
              }}
              source={require('./assets/images/c856a039-f64f-4266-aa12-2ab582564603.png')}
            />
            <ImageBackground
              style={{
                width: '2.37%',
                height: '2.97%',
                position: 'absolute',
                top: '53.85%',
                left: '48.26%',
                zIndex: 30,
              }}
              source={require('./assets/images/b34936dd-3f50-4fa4-aae6-97508453e1a7.png')}
            />
            <ImageBackground
              style={{
                width: '7.81%',
                height: '3.5%',
                position: 'absolute',
                top: '54.54%',
                left: '52.69%',
                zIndex: 14,
              }}
              source={require('./assets/images/0fa887f7-c143-4fb6-b70c-964dfc00a87e.png')}
            />
            <ImageBackground
              style={{
                width: '11.8%',
                height: '5.37%',
                position: 'absolute',
                top: '54.79%',
                left: '66.95%',
                zIndex: 23,
              }}
              source={require('./assets/images/c603626f-6629-4be5-9af6-7f221f43b285.png')}
            />
            <ImageBackground
              style={{
                width: '3.14%',
                height: '3.51%',
                position: 'absolute',
                top: '54.96%',
                left: '63.65%',
                zIndex: 41,
              }}
              source={require('./assets/images/933708c9-a8b2-4282-88b7-5b9053fb5b2c.png')}
            />
            <ImageBackground
              style={{
                width: '1.8%',
                height: '3.25%',
                position: 'absolute',
                top: '54.98%',
                left: '61.25%',
                zIndex: 43,
              }}
              source={require('./assets/images/03463a48-416d-41fe-bc9b-71465ae5df5f.png')}
            />
            <View
              style={{
                width: '63.17%',
                height: '13.07%',
                position: 'absolute',
                top: '55.2%',
                left: '17.07%',
                zIndex: 32,
              }}
            >
              <View
                style={{
                  width: 205.887,
                  height: 41.853,
                  position: 'relative',
                  zIndex: 33,
                  marginTop: 0.27,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.38,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 34,
                  }}
                  source={require('./assets/images/5f5fc3b6-61e3-42e0-84ef-4b96be209a5a.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: '13.2%',
                height: '1.84%',
                position: 'absolute',
                top: '58.6%',
                left: '53.71%',
                zIndex: 28,
              }}
              source={require('./assets/images/a3827b3e-dada-4ae8-bbfa-782fa347f0e9.png')}
            />
            <View
              style={{
                width: '3.71%',
                height: '3.47%',
                position: 'absolute',
                top: '60.53%',
                left: '76.53%',
                zIndex: 19,
              }}
            >
              <View
                style={{
                  width: 11.98,
                  height: 10.576,
                  position: 'relative',
                  zIndex: 20,
                  marginTop: 0.69,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.2,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 21,
                  }}
                  source={require('./assets/images/2638672b-b21c-4aa6-8ecc-a93afc22f5cc.png')}
                />
              </View>
            </View>
            <ImageBackground
              style={{
                width: '44.64%',
                height: '3.41%',
                position: 'absolute',
                top: '60.88%',
                left: '31.82%',
                zIndex: 22,
              }}
              source={require('./assets/images/cb19253f-6795-481f-91a8-a15c39d206f3.png')}
            />
            <ImageBackground
              style={{
                width: '38.63%',
                height: '2.48%',
                position: 'absolute',
                top: '62.83%',
                left: '38.23%',
                zIndex: 16,
              }}
              source={require('./assets/images/cd523797-c12d-43cd-a9e0-087a7972dbb5.png')}
            />
            <View
              style={{
                width: '3.17%',
                height: '1.07%',
                position: 'absolute',
                top: '63.73%',
                left: '77.07%',
                zIndex: 35,
              }}
            >
              <View
                style={{
                  width: 10.191,
                  height: 2.793,
                  position: 'relative',
                  zIndex: 36,
                  marginTop: 0.13,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.26,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 37,
                  }}
                  source={require('./assets/images/52d117c7-2b2a-4b70-8636-cdcbf91acebe.png')}
                />
              </View>
            </View>
            <View
              style={{
                width: '2.2%',
                height: '5.75%',
                position: 'absolute',
                top: '71.45%',
                left: '31.36%',
                zIndex: 52,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 53,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 54,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 55,
                    }}
                    source={require('./assets/images/4bee663c-069a-4092-9927-c7d86d8e31b2.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '4.47%',
                height: '4.01%',
                position: 'absolute',
                top: '71.91%',
                left: '40.67%',
                zIndex: 64,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 65,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 66,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 67,
                    }}
                    source={require('./assets/images/bd936f3e-075c-498a-9997-cdf3b57300a6.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '4.47%',
                height: '4.01%',
                position: 'absolute',
                top: '71.91%',
                left: '55.88%',
                zIndex: 76,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 77,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 78,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 79,
                    }}
                    source={require('./assets/images/9e7bea08-d074-407f-bb3b-c9ed1b3e2910.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '3.7%',
                height: '3.93%',
                position: 'absolute',
                top: '71.98%',
                left: '65.56%',
                zIndex: 84,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 85,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 86,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 87,
                    }}
                    source={require('./assets/images/7b0dbd3a-1e84-4f8e-9376-c0b5b2c5becd.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '3.25%',
                height: '3.93%',
                position: 'absolute',
                top: '71.99%',
                left: '34.43%',
                zIndex: 56,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 57,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 58,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 59,
                    }}
                    source={require('./assets/images/ec979d54-46d3-4515-adf9-46f0068c2d9b.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '2.03%',
                height: '4.95%',
                position: 'absolute',
                top: '72.09%',
                left: '38.22%',
                zIndex: 60,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 61,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 62,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 63,
                    }}
                    source={require('./assets/images/d7e21f0c-f82b-4f2d-9208-f4acff608c64.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '4.21%',
                height: '3.83%',
                position: 'absolute',
                top: '72.09%',
                left: '45.59%',
                zIndex: 68,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 69,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 70,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 71,
                    }}
                    source={require('./assets/images/77dd677c-3e30-48e8-9525-b09b4bc8d274.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '3.25%',
                height: '3.83%',
                position: 'absolute',
                top: '72.09%',
                left: '52.33%',
                zIndex: 72,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 73,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 74,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 75,
                    }}
                    source={require('./assets/images/747f0bd7-bc7c-4ae0-981b-92c0f2b661b6.png')}
                  />
                </View>
              </View>
            </View>
            <View
              style={{
                width: '4.2%',
                height: '3.91%',
                position: 'absolute',
                top: '72.09%',
                left: '60.75%',
                zIndex: 80,
              }}
            >
              <View
                style={{
                  width: '100%',
                  height: '100%',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  zIndex: 81,
                }}
              >
                <View
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 82,
                  }}
                >
                  <ImageBackground
                    style={{
                      width: '100%',
                      height: '100%',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      zIndex: 83,
                    }}
                    source={require('./assets/images/2dd4eda0-21d2-4257-8db0-d3b6e21cfdc9.png')}
                  />
                </View>
              </View>
            </View>
            <ImageBackground
              style={{
                width: '24.77%',
                height: '0.31%',
                position: 'absolute',
                top: '74.01%',
                left: '5.7%',
                zIndex: 9,
              }}
              source={require('./assets/images/5c44c348-8afd-44bf-aaf8-ef676e34dd10.png')}
            />
            <ImageBackground
              style={{
                width: '24.77%',
                height: '0.31%',
                position: 'absolute',
                top: '74.17%',
                left: '69.53%',
                zIndex: 88,
              }}
              source={require('./assets/images/a62af3fa-8919-448a-a66f-9f2b56ea5e51.png')}
            />
            <View
              style={{
                width: '64.53%',
                height: '3.2%',
                position: 'absolute',
                top: '79.83%',
                left: '17.34%',
                zIndex: 97,
              }}
            >
              <View
                style={{
                  width: 210.082,
                  height: 10.294,
                  position: 'relative',
                  zIndex: 98,
                  marginTop: 0.02,
                  marginRight: 0,
                  marginBottom: 0,
                  marginLeft: 0.4,
                }}
              >
                <ImageBackground
                  style={{
                    width: '100%',
                    height: '100%',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    zIndex: 99,
                  }}
                  source={require('./assets/images/2521fd8e-bf05-4c44-8af9-2a0651d9fd26.png')}
                />
              </View>
            </View>
          </View>
          <Text
            style={{
              display: 'flex',
              width: 312,
              height: 86,
              justifyContent: 'center',
              alignItems: 'flex-start',
              fontFamily: 'Poppins',
              fontSize: 23,
              fontWeight: '600',
              lineHeight: 34.5,
              color: '#b6e5ff',
              position: 'relative',
              textAlign: 'center',
              zIndex: 100,
              marginTop: 14,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 55,
            }}
          >
            Satu catatan kecil, satu langkah besar untuk hasil yang lebih baik!
          </Text>
          <View
            style={{
              width: 330,
              height: 60,
              backgroundColor: '#b6e5ff',
              borderTopLeftRadius: 7,
              borderTopRightRadius: 7,
              borderBottomRightRadius: 7,
              borderBottomLeftRadius: 7,
              position: 'relative',
              zIndex: 3,
              marginTop: 239,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 50,
            }}
          >
            <Text
              style={{
                display: 'flex',
                height: 38,
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
                fontFamily: 'Poppins',
                fontSize: 23,
                fontWeight: '600',
                lineHeight: 34.5,
                color: '#052844',
                position: 'absolute',
                top: 11,
                left: '50%',
                textAlign: 'left',
                zIndex: 4,
                transform: [{ translateX: -137 }],
              }}
              numberOfLines={1}
            >
              Jadilah Kapten Cerdas!
            </Text>
          </View>
          <ImageBackground
            style={{
              width: 139,
              height: 5,
              borderTopLeftRadius: 100,
              borderTopRightRadius: 100,
              borderBottomRightRadius: 100,
              borderBottomLeftRadius: 100,
              position: 'relative',
              zIndex: 1,
              marginTop: 40,
              marginRight: 0,
              marginBottom: 0,
              marginLeft: 147,
            }}
            source={require('./assets/images/d232dae0-b995-4506-ad3e-3e25a8f41144.png')}
            resizeMode='cover'
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
